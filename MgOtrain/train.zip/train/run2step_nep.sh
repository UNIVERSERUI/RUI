#!/bin/bash

# 第一次运行nep
/home/xue/software/GPUMD/GPUMD-master/src/nep

# 修改nep.in文件
if [ -f "nep.in" ]; then
    # 使用sed直接修改文件
    sed -i.bak -e 's/\(lambda_e\)[[:space:]]\+[0-9.]\+/\1   5/' \
               -e 's/\(lambda_v\)[[:space:]]\+[0-9.]\+/\1   0.5/' \
               -e 's/\(batch\)[[:space:]]\+[0-9]\+/\1 4500/' \
               -e 's/\(generation\)[[:space:]]\+[0-9]\+/\1 100000/' nep.in
    
    # 显示修改内容
    echo "nep.in文件已修改："
    grep -E "lambda_e|lambda_v|batch|generation" nep.in
else
    echo "警告：未找到nep.in文件"
fi

# 第二次运行nep
/home/xue/software/GPUMD/GPUMD-master/src/nep
