import sys
import matplotlib.pyplot as plt
import numpy as np
import os
# from cycler import cycler

# custom_colors = ['#9BBBE1', '#EAB883', '#A9CA70', '#DD7C4F', '#F09BA0', '#B58C9A']
# plt.rcParams['axes.prop_cycle'] = cycler(color=custom_colors)

# Function to safely load data files
def safe_loadtxt(filename):
    try:
        if os.path.exists(filename):
            return np.loadtxt(filename)
        else:
            return None
    except Exception as e:
        print(f"Warning: Could not load {filename}: {e}")
        return None

# Load data
loss = np.loadtxt('loss.out')
energy_train = safe_loadtxt('energy_train.out')
force_train = safe_loadtxt('force_train.out')
stress_train = safe_loadtxt('stress_train.out')

# Try to load test data
energy_test = safe_loadtxt('energy_test.out')
force_test = safe_loadtxt('force_test.out')
stress_test = safe_loadtxt('stress_test.out')

# Filter out rows with invalid stress data (train)
if stress_train is not None:
    valid_rows = ~np.any(np.abs(stress_train[:, :12]) > 1e6, axis=1)
    stress_train = stress_train[valid_rows]

# Filter out rows with invalid stress data (test)
if stress_test is not None:
    valid_rows = ~np.any(np.abs(stress_test[:, :12]) > 1e6, axis=1)
    stress_test = stress_test[valid_rows]

# Function to calculate RMSE
def calculate_rmse(pred, actual):
    return np.sqrt(np.mean((pred - actual) ** 2))

# Function to calculate MAE
def calculate_mae(pred, actual):
    return np.mean(np.abs(pred - actual))

# Function to calculate R²
def calculate_r2(pred, actual):
    ss_tot = np.sum((actual - np.mean(actual)) ** 2)
    ss_res = np.sum((pred - actual) ** 2)
    return 1 - ss_res / ss_tot if ss_tot != 0 else 1.0

# Function to calculate dynamic axis limits
def calculate_limits(data_list, padding=0.08):
    # Combine all data in the list to calculate min and max
    all_data = []
    for data in data_list:
        if data is not None:
            if len(data.shape) == 1:
                all_data.extend(data)
            else:
                all_data.extend(data.reshape(-1))
    
    if not all_data:
        return 0, 1
    
    data_min = np.min(all_data)
    data_max = np.max(all_data)
    data_range = data_max - data_min
    return data_min - padding * data_range, data_max + padding * data_range

# Create a subplot with 2 rows and 2 columns
fig, axs = plt.subplots(2, 2, figsize=(9, 7), dpi=100)

# Determine loss plot format
if loss[0, 0] == 100:
    xlabel = 'Generation/100'
    # Plot train and test loss columns
    train_cols = slice(1, 7)  # loss[:, 1:7] - training loss
    test_cols = slice(7, 10)  # loss[:, 7:10] - test loss (assuming 3 columns for test)
    train_legend_labels = ['Total', 'L1-Reg', 'L2-Reg', 'Energy-train', 'Force-train', 'Virial-train']
    test_legend_labels = ['Energy-test', 'Force-test', 'Virial-test']
elif loss[0, 0] == 1:
    xlabel = 'Epoch'
    # Plot train and test loss columns
    train_cols = slice(1, 5)  # loss[:, 1:5] - training loss
    test_cols = slice(5, 8)   # loss[:, 5:8] - test loss (assuming 3 columns for test)
    train_legend_labels = ['Total', 'Energy-train', 'Force-train', 'Virial-train']
    test_legend_labels = ['Energy-test', 'Force-test', 'Virial-test']
else:
    raise ValueError("Unexpected loss data format.")

# Plotting the loss figure - training loss
lines_train = axs[0, 0].loglog(loss[:, train_cols], '-', linewidth=2)

# Plotting the loss figure - test loss (if exists)
if loss.shape[1] > train_cols.stop:
    test_data = loss[:, test_cols]
    # Use dashed lines for test loss
    lines_test = axs[0, 0].loglog(test_data, '--', linewidth=2)
    # Combine legend labels
    legend_labels = train_legend_labels + test_legend_labels
else:
    legend_labels = train_legend_labels

axs[0, 0].set_xlabel(xlabel, fontsize=10)
axs[0, 0].set_ylabel('Loss functions', fontsize=10)
axs[0, 0].tick_params(axis='both', labelsize=10)
axs[0, 0].legend(legend_labels, prop={'size': 8})
axs[0, 0].axis('tight')

# Plotting the energy figure
if energy_train is not None or energy_test is not None:
    # Calculate axis limits using both train and test data
    energy_data_for_limits = []
    if energy_train is not None:
        energy_data_for_limits.append(energy_train[:, 0])
        energy_data_for_limits.append(energy_train[:, 1])
    if energy_test is not None:
        energy_data_for_limits.append(energy_test[:, 0])
        energy_data_for_limits.append(energy_test[:, 1])
    
    xmin_energy, xmax_energy = calculate_limits(energy_data_for_limits)
    axs[0, 1].set_xlim(xmin_energy, xmax_energy)
    axs[0, 1].set_ylim(xmin_energy, xmax_energy)
    
    # Plot train energy
    if energy_train is not None:
        axs[0, 1].plot(energy_train[:, 1], energy_train[:, 0], 'b.', markersize=10, alpha=0.7, label='Train')
        # Calculate and display RMSE, MAE, and R2 for train energy
        energy_rmse_train = calculate_rmse(energy_train[:, 0], energy_train[:, 1]) * 1000
        energy_mae_train = calculate_mae(energy_train[:, 0], energy_train[:, 1]) * 1000
        energy_r2_train = calculate_r2(energy_train[:, 0], energy_train[:, 1])
    
    # Plot test energy
    if energy_test is not None:
        axs[0, 1].plot(energy_test[:, 1], energy_test[:, 0], 'r.', markersize=10, alpha=0.7, label='Test')
        # Calculate and display RMSE, MAE, and R2 for test energy
        energy_rmse_test = calculate_rmse(energy_test[:, 0], energy_test[:, 1]) * 1000
        energy_mae_test = calculate_mae(energy_test[:, 0], energy_test[:, 1]) * 1000
        energy_r2_test = calculate_r2(energy_test[:, 0], energy_test[:, 1])
    
    # Plot diagonal line
    axs[0, 1].plot([xmin_energy, xmax_energy], [xmin_energy, xmax_energy], linewidth=2, color='grey', linestyle='--')
    
    axs[0, 1].set_xlabel('DFT energy (eV/atom)', fontsize=10)
    axs[0, 1].set_ylabel('NEP energy (eV/atom)', fontsize=10)
    axs[0, 1].tick_params(axis='both', labelsize=10)
    axs[0, 1].legend()
    axs[0, 1].axis('tight')
    
    # Create text for metrics
    metrics_text = ""
    if energy_train is not None:
        metrics_text += f"Train:\nR²: {energy_r2_train:.4f}\nMAE: {energy_mae_train:.2f} meV/atom\nRMSE: {energy_rmse_train:.2f} meV/atom\n"
    if energy_test is not None:
        metrics_text += f"\nTest:\nR²: {energy_r2_test:.4f}\nMAE: {energy_mae_test:.2f} meV/atom\nRMSE: {energy_rmse_test:.2f} meV/atom"
    
    axs[0, 1].text(0.7, 0.12, metrics_text, 
                   transform=axs[0, 1].transAxes, fontsize=9, verticalalignment='center', horizontalalignment='center')
else:
    axs[0, 1].axis('off')
    axs[0, 1].text(0.5, 0.5, 'No energy data', horizontalalignment='center', verticalalignment='center')

# Plotting the force figure
if force_train is not None or force_test is not None:
    # Calculate axis limits using both train and test data
    force_data_for_limits = []
    if force_train is not None:
        force_data_for_limits.append(force_train[:, 0:3].reshape(-1))
        force_data_for_limits.append(force_train[:, 3:6].reshape(-1))
    if force_test is not None:
        force_data_for_limits.append(force_test[:, 0:3].reshape(-1))
        force_data_for_limits.append(force_test[:, 3:6].reshape(-1))
    
    xmin_force, xmax_force = calculate_limits(force_data_for_limits)
    axs[1, 0].set_xlim(xmin_force, xmax_force)
    axs[1, 0].set_ylim(xmin_force, xmax_force)
    
    # Plot train forces
    if force_train is not None:
        axs[1, 0].plot(force_train[:, 3:6], force_train[:, 0:3], 'b.', markersize=10, alpha=0.7, label='Train')
        # Calculate and display RMSE, MAE, and R² for train forces
        force_rmse_train = [calculate_rmse(force_train[:, i], force_train[:, i + 3]) for i in range(3)]
        force_mae_train = [calculate_mae(force_train[:, i], force_train[:, i + 3]) for i in range(3)]
        force_r2_train = [calculate_r2(force_train[:, i], force_train[:, i + 3]) for i in range(3)]
        mean_force_rmse_train = np.mean(force_rmse_train) * 1000
        mean_force_mae_train = np.mean(force_mae_train) * 1000
        mean_force_r2_train = np.mean(force_r2_train)
    
    # Plot test forces
    if force_test is not None:
        axs[1, 0].plot(force_test[:, 3:6], force_test[:, 0:3], 'r.', markersize=10, alpha=0.7, label='Test')
        # Calculate and display RMSE, MAE, and R² for test forces
        force_rmse_test = [calculate_rmse(force_test[:, i], force_test[:, i + 3]) for i in range(3)]
        force_mae_test = [calculate_mae(force_test[:, i], force_test[:, i + 3]) for i in range(3)]
        force_r2_test = [calculate_r2(force_test[:, i], force_test[:, i + 3]) for i in range(3)]
        mean_force_rmse_test = np.mean(force_rmse_test) * 1000
        mean_force_mae_test = np.mean(force_mae_test) * 1000
        mean_force_r2_test = np.mean(force_r2_test)
    
    # Plot diagonal line
    axs[1, 0].plot([xmin_force, xmax_force], [xmin_force, xmax_force], linewidth=2, color='grey', linestyle='--')
    
    axs[1, 0].set_xlabel(r'DFT force (eV/$\mathrm{\AA}$)', fontsize=10)
    axs[1, 0].set_ylabel(r'NEP force (eV/$\mathrm{\AA}$)', fontsize=10)
    axs[1, 0].tick_params(axis='both', labelsize=10)
    axs[1, 0].legend()
    axs[1, 0].axis('tight')
    
    # Create text for metrics
    metrics_text = ""
    if force_train is not None:
        metrics_text += f"Train:\nR²: {mean_force_r2_train:.4f}\nMAE: {mean_force_mae_train:.2f} meV/Å\nRMSE: {mean_force_rmse_train:.2f} meV/Å\n"
    if force_test is not None:
        metrics_text += f"\nTest:\nR²: {mean_force_r2_test:.4f}\nMAE: {mean_force_mae_test:.2f} meV/Å\nRMSE: {mean_force_rmse_test:.2f} meV/Å"
    
    axs[1, 0].text(0.7, 0.12, metrics_text, 
                   transform=axs[1, 0].transAxes, fontsize=9, verticalalignment='center', horizontalalignment='center')
else:
    axs[1, 0].axis('off')
    axs[1, 0].text(0.5, 0.5, 'No force data', horizontalalignment='center', verticalalignment='center')

# Plotting the stress figure 
stress_data_exists = False
if stress_train is not None and stress_train.shape[0] > 0:
    stress_data_exists = True
if stress_test is not None and stress_test.shape[0] > 0:
    stress_data_exists = True

if stress_data_exists:
    # Calculate axis limits using both train and test data
    stress_data_for_limits = []
    if stress_train is not None and stress_train.shape[0] > 0:
        stress_data_for_limits.append(stress_train[:, 0:6].reshape(-1))
        stress_data_for_limits.append(stress_train[:, 6:12].reshape(-1))
    if stress_test is not None and stress_test.shape[0] > 0:
        stress_data_for_limits.append(stress_test[:, 0:6].reshape(-1))
        stress_data_for_limits.append(stress_test[:, 6:12].reshape(-1))
    
    xmin_stress, xmax_stress = calculate_limits(stress_data_for_limits)
    axs[1, 1].set_xlim(xmin_stress, xmax_stress)
    axs[1, 1].set_ylim(xmin_stress, xmax_stress)
    
    # Plot train stresses
    if stress_train is not None and stress_train.shape[0] > 0:
        axs[1, 1].plot(stress_train[:, 6:12], stress_train[:, 0:6], 'b.', markersize=10, alpha=0.7, label='Train')
        # Calculate and display RMSE, MAE, and R² for train stresses
        stress_rmse_train = [calculate_rmse(stress_train[:, i], stress_train[:, i + 6]) for i in range(6)]
        stress_mae_train = [calculate_mae(stress_train[:, i], stress_train[:, i + 6]) for i in range(6)]
        stress_r2_train = [calculate_r2(stress_train[:, i], stress_train[:, i + 6]) for i in range(6)]
        mean_stress_rmse_train = np.mean(stress_rmse_train)
        mean_stress_mae_train = np.mean(stress_mae_train)
        mean_stress_r2_train = np.mean(stress_r2_train)
    
    # Plot test stresses
    if stress_test is not None and stress_test.shape[0] > 0:
        axs[1, 1].plot(stress_test[:, 6:12], stress_test[:, 0:6], 'r.', markersize=10, alpha=0.7, label='Test')
        # Calculate and display RMSE, MAE, and R² for test stresses
        stress_rmse_test = [calculate_rmse(stress_test[:, i], stress_test[:, i + 6]) for i in range(6)]
        stress_mae_test = [calculate_mae(stress_test[:, i], stress_test[:, i + 6]) for i in range(6)]
        stress_r2_test = [calculate_r2(stress_test[:, i], stress_test[:, i + 6]) for i in range(6)]
        mean_stress_rmse_test = np.mean(stress_rmse_test)
        mean_stress_mae_test = np.mean(stress_mae_test)
        mean_stress_r2_test = np.mean(stress_r2_test)
    
    # Plot diagonal line
    axs[1, 1].plot([xmin_stress, xmax_stress], [xmin_stress, xmax_stress], linewidth=2, color='grey', linestyle='--')
    
    axs[1, 1].set_xlabel('DFT stress (GPa)', fontsize=10)
    axs[1, 1].set_ylabel('NEP stress (GPa)', fontsize=10)
    axs[1, 1].tick_params(axis='both', labelsize=10)
    axs[1, 1].legend()
    axs[1, 1].axis('tight')
    
    # Create text for metrics
    metrics_text = ""
    if stress_train is not None and stress_train.shape[0] > 0:
        metrics_text += f"Train:\nR²: {mean_stress_r2_train:.4f}\nMAE: {mean_stress_mae_train:.4f} GPa\nRMSE: {mean_stress_rmse_train:.4f} GPa\n"
    if stress_test is not None and stress_test.shape[0] > 0:
        metrics_text += f"\nTest:\nR²: {mean_stress_r2_test:.4f}\nMAE: {mean_stress_mae_test:.4f} GPa\nRMSE: {mean_stress_rmse_test:.4f} GPa"
    
    axs[1, 1].text(0.7, 0.12, metrics_text, 
                   transform=axs[1, 1].transAxes, fontsize=9, verticalalignment='center', horizontalalignment='center')
else:
    axs[1, 1].axis('off')
    axs[1, 1].text(0.5, 0.5, 'No stress data', horizontalalignment='center', verticalalignment='center')

# Adjust layout for better spacing
plt.tight_layout()

# Save or show the plot
if len(sys.argv) > 1 and sys.argv[1] == 'save':
    plt.savefig('train_test.png', dpi=300)
else:
    # Check if the current backend is non-interactive
    from matplotlib import get_backend
    if get_backend().lower() in ['agg', 'cairo', 'pdf', 'ps', 'svg']:
        print("Unable to display the plot due to the non-interactive backend.")
        print("The plot has been automatically saved as 'train_test.png'.")
        plt.savefig('train_test.png', dpi=300)
    else:
        plt.show()
